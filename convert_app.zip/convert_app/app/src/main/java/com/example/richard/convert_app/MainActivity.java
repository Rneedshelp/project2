package com.example.richard.convert_app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    EditText Mbps;
    EditText MiB;
    Button Conversion;
    TextView Result;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Mbps = (EditText)findViewById(R.id.net_speed_input);
        MiB = (EditText)findViewById(R.id.file_size_input);
        Conversion = (Button)findViewById(R.id.transfer_time_convert_button);
        Result = (TextView)findViewById(R.id.transfer_time_result);
    }

    public double fileconverter()
    {
        int mpbs = Integer.valueOf(Mbps.getText().toString()); //100
        int mib = Integer.valueOf(MiB.getText().toString());  //100
        double value = (mib/0.119209) / mpbs;
        String.format("%.2f",value);
        return value;
    }
    public void TransferTimeConvert(View V)
    {
        double val;
        if(Conversion.isPressed())
        {
            val = fileconverter();
            Result.setText(new Double(String.format("%.1f",val)).toString());
        }
    }
}
